<?php

class Comments extends Mustache {
	public function title() {
		return 'A Comedy of Errors';
	}
}