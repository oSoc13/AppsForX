<?php

class PragmaUnescaped extends Mustache {
	public $vs = 'Bear > Shark';
}