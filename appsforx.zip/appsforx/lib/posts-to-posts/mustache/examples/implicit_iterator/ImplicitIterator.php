<?php

class ImplicitIterator extends Mustache {
	protected $data = array('Donkey Kong', 'Luigi', 'Mario', 'Peach', 'Yoshi');
}