<?php

class InvertedDoubleSection extends Mustache {
	public $t = false;
	public $two = 'second';
}