custom-post-type-archive-menu
=============================

This WordPress plugin makes it easy to add a new menu items for custom post type archives, and also fixes the bug which shows the Blog menu item as the parent when on any custom post type page or archive.

~Current Version:1.3~
